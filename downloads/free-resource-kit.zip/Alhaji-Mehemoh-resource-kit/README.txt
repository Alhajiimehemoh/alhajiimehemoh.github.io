Free resource kit by Alhaji Ibrahim Mehemoh

- M&E data quality checklist (PDF): Completeness, timeliness, accuracy, consistency, duplicates and privacy, on one sheet you run before every report.
- Indicator reference sheet (PDF): Define each indicator once: numerator, denominator, source, frequency and limits. Includes a worked example and a blank sheet.
- Monthly programme report (PDF): A two-page structure for monthly reports: highlights, indicator table, challenges, actions and data quality notes.
- XLSForm cheat sheet (PDF): Question types, required, relevant, constraint and calculation syntax with copy-ready examples and common mistakes.
- Dashboard design checklist (PDF): Audience, layout, charts, numbers and trust: a one-page review to run before you share any Power BI or Excel dashboard.
- Backup and security checklist (PDF): The 3-2-1 backup rule, passwords, updates, antivirus and safe sharing for small offices, clinics and NGOs.
- Field data collection supervision checklist (PDF): What a supervisor checks during a field visit: devices, consent, form use, GPS, sync and data quality spot checks.
- New staff IT setup checklist (PDF): Accounts, device setup, security and training for a new colleague, plus the matching exit checklist.
- Stock tracker (Excel): Opening stock, received, issued and losses give closing stock, months of stock and an automatic REORDER or OVERSTOCK flag.
- Indicator tracker (Excel): Baseline, annual target and quarterly results for count indicators, with year-to-date, percent of target and a traffic-light status.
- Data cleaning log (Excel): Record every issue found and every correction made, with drop-down issue types and an automatic summary by type and status.
- IT asset register (Excel): Every computer, phone, printer and router in one list, with warranty status and next service date worked out for you.
- Sample EPI XLSForm (XLSForm): A short monthly facility form with validation, skip logic and a calculated field. Upload to Survey123 Connect or KoboToolbox and adapt.

Free to use and adapt. Please keep the credit line.
alhajiimehemoh.github.io  |  alhajiimehemoh@gmail.com
